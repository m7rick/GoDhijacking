// 方法很简单：
//
//	1.解析PE文件导入表信息
//	2.获取导入表DLL名称和 当前PE路径下的DLL进行循环对比
//	3.存在即可劫持
package src

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/fatih/color"
)

var (
	red    = color.New(color.FgRed).SprintFunc()
	green  = color.New(color.FgGreen).SprintFunc()
	blue   = color.New(color.FgBlue).SprintFunc()
	yellow = color.New(color.FgYellow).SprintFunc()
)
var OutFileName string
var PeArchs string

var processedDirs = make(map[string]bool) // 存储已处理过的目录

func processExesAndDllsInSameDir(dirPath string) (exePaths, dllNames []string) {
	files, err := os.ReadDir(dirPath)
	if err != nil {
		fmt.Printf("error reading directory %s: %v\n", dirPath, err)
		return nil, nil
	}

	for _, file := range files {
		filePath := filepath.Join(dirPath, file.Name())
		if file.IsDir() {
			continue
		}
		if strings.HasSuffix(strings.ToLower(file.Name()), ".exe") {
			exePaths = append(exePaths, filePath)
		} else if strings.HasSuffix(strings.ToLower(file.Name()), ".dll") {
			dllNames = append(dllNames, file.Name())
		}
	}
	return exePaths, dllNames
}

// autoFinddllhijack 接收两个字符串切片并比较它们找出共有的字符串（忽略大小写）
func autoFinddllhijack(dllimport, pathdll []string) []string {
	found := []string{}
	pathdllMap := make(map[string]struct{})

	for _, item := range pathdll {
		pathdllMap[strings.ToLower(item)] = struct{}{}
	}

	for _, item := range dllimport {
		lowerItem := strings.ToLower(item)
		if _, exists := pathdllMap[lowerItem]; exists {
			found = append(found, item)
		}
	}

	return found
}

// func autoFinddllhijack(dllimport, pathdll []string) []string {
// 	found := []string{}                       // 创建一个空切片用来存储找到的相同字符串
// 	dllimportMap := make(map[string]struct{}) // 使用一个map来提高查找效率

// 	// 把dllimport的所有元素添加到map中，转为小写来忽略大小写
// 	for _, item := range dllimport {
// 		dllimportMap[strings.ToLower(item)] = struct{}{}
// 	}

// 	// 遍历pathdll，用map检查是否有相同的字符串（忽略大小写）
// 	for _, item := range pathdll {
// 		lowerItem := strings.ToLower(item) // 先转为小写
// 		// 如果找到相同的字符串，则把它添加到found切片中
// 		if _, exists := dllimportMap[lowerItem]; exists {
// 			found = append(found, item) // 添加原始字符串
// 		}
// 	}

// 	return found // 返回找到的相同字符串
// }

func visit(path string, f os.FileInfo, err error) error {
	if err != nil {
		return err
	}
	if f.IsDir() {
		return nil
	}

	if strings.HasSuffix(strings.ToLower(f.Name()), ".exe") {
		dirPath := filepath.Dir(path)

		// 检查该目录是否已经处理过
		if _, processed := processedDirs[dirPath]; processed {
			return nil
		}

		// 获取当前目录下的所有 .exe 和 .dll 文件
		exePaths, dllNames := processExesAndDllsInSameDir(dirPath)
		if len(exePaths) == 0 {
			// log.Println("[*] The current directory does not contain any exe files")

		} else {

			log.Println(blue("[+] The current number of files processed is: ", len(exePaths)))
			dir := filepath.Dir(exePaths[0])
			log.Printf("[+] The current path: %s", dir)
			// log.Println(exePaths, dllNames) // DLL 对比 导入表信息
			// TODO: 在这里处理这些exe和dll文件
			// 解析PE文件 获取导入表信息
			for _, ExeName := range exePaths {
				// log.Printf(yellow("[+] Searching......... "))
				// log.Println("当前解析：", ExeName)
				importdllpath, arch := ParseAndPrintImports(ExeName)
				founddll := autoFinddllhijack(importdllpath, dllNames)
				if len(founddll) != 0 {

					Msg := fmt.Sprintf("\n[+] File: %s \n    PE Arch: %s \n    Found DLL: %s", ExeName, arch, founddll[0])
					fmt.Println(green(Msg))
					// 成功结果写入文本
					file, err := os.OpenFile("./bin/"+OutFileName, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0644)
					if err != nil {
						break
					}
					defer file.Close()

					file.WriteString("[+] Path :		" + ExeName + "  Arch : " + arch + "\n")
					// 将内容追加写入文件 (循环所有列表)
					// for _, line := range founddll {
					// 	_, err = file.WriteString("\tDLL  :		" + line + "\n")
					// 	if err != nil {
					// 		return err
					// 	}
					// }
					// 只写入第一个
					_, err = file.WriteString("\tDLL  :		" + founddll[0] + "\n\n")
					if err != nil {
						break
					}
				}

			}

		}

		// 标记该目录已处理
		processedDirs[dirPath] = true
	}
	return nil
}

func FindPath(path, outfilename, arch string) {
	// 获取指定路径
	root := path
	OutFileName = outfilename
	PeArchs = arch
	err := filepath.Walk(root, visit)
	if err != nil {
		log.Printf("[*] error walking the path %v: %v\n", root, err)
	}

	// ======================================================================================

}
