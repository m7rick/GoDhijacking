package src

import (
	"fmt"
	"log"
	"os"

	peparser "github.com/saferwall/pe"
)

// 导出DLL 模版
func DLLParse(dllpath, code string, msgs bool) {

	// 创建 PE 解析器对象
	pe, err := peparser.New(dllpath, &peparser.Options{})
	if err != nil {
		log.Fatalf("[*] Error while opening file: %s, reason: %v", dllpath, err)
	}

	// 解析 PE 文件
	err = pe.Parse()
	if err != nil {
		log.Fatalf("[*] Error while parsing file: %s, reason: %v", dllpath, err)
	}

	// 获取导出函数列表
	exports := pe.Export.Functions
	if len(exports) == 0 {
		fmt.Println("[*] No exports found in the DLL.")
		return
	}

	// 打印导出函数
	// fmt.Println("Exported functions:")
	// for _, exp := range exports {
	// 	fmt.Println(exp.Name)
	// }

	// 生成函数定义的字符串
	var functionDefinitions string
	for _, exp := range exports {

		if msgs == true {
			functionDefinitions += fmt.Sprintf(`extern "C" DLLMAIN_API void %s (){
	MessageBoxW(0, L"Tips", L"%s", 0);
}`+"\n\n", exp.Name, exp.Name)

		} else {
			if code == "GO" {
				functionDefinitions += fmt.Sprintf("\n//export %s\nfunc %s(){}\n", exp.Name, exp.Name)
			}
			if code == "CPP" {
				functionDefinitions += fmt.Sprintf(`extern "C" DLLMAIN_API void %s (){
	}`+"\n\n", exp.Name)
			}

		}

	}

	if code == "GO" {
		// 生成完整的 Go 代码
		goCode := fmt.Sprintf(`package main
import "C"
	
%s
func init(){}
	
func main(){}
`, functionDefinitions)

		// 写入 Go 代码到文件
		err = os.WriteFile("./bin/DLLTempLates.go", []byte(goCode), 0644)
		if err != nil {
			log.Fatalf("[*] Error while writing to file: %v", err)
		}

		log.Println("[+] Successfully generated the Go code.")

	} else {
		// ========================= 生成CPP 模版 ============================
		cppCode := fmt.Sprintf(`#include <windows.h>
#define DLLMAIN_API __declspec(dllexport)
		
// 导出函数列子
%s
		
BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		MessageBoxW(0, L"Tips", L"DLLMain", 0);
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}
		
		
	`, functionDefinitions)

		// 写入 CPP 代码到文件
		err = os.WriteFile("./bin/CPPTempLates.cpp", []byte(cppCode), 0644)
		if err != nil {
			log.Fatalf("[*] Error while writing to file: %v", err)
		}

		log.Println("[+] Successfully generated the CPP code.")

	}

}

// 解析导入表信息 (半自动化DLL劫持)
func ParseAndPrintImports(filename string) ([]string, string) {
	// 创建 PE 解析器对象
	pe, err := peparser.New(filename, &peparser.Options{})
	if err != nil {
		log.Fatalf("[*] Error while opening file: %s, reason: %v", filename, err)
	}

	// 解析 PE 文件
	err = pe.Parse()
	if err != nil {
		log.Fatalf("[*] Error while parsing file: %s, reason: %v", filename, err)
	}

	var arch string
	if pe.Is32 {
		arch = "32-bit"
	} else if pe.Is64 {
		arch = "64-bit"
	}

	// 根据 PeArch 值获取导入表
	var imports []peparser.Import
	if PeArchs == "32" && pe.Is32 {
		imports = pe.Imports
	} else if PeArchs == "64" && pe.Is64 {
		imports = pe.Imports
	} else if PeArchs == "all" {
		imports = pe.Imports
	} else {
		// 如果不满足指定条件，直接返回空导入表和空字符串
		log.Printf("[*] The current PE File not is %s , skipping", PeArchs)
		return []string{}, ""
	}

	if len(imports) == 0 {
		fmt.Println("[*] No imports found in the PE file.")
	}

	var importNames []string

	for _, imp := range imports {
		importNames = append(importNames, imp.Name)
	}

	return importNames, arch
}
