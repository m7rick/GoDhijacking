# GoDHijack
> Red team tool designed for quickly identifying hijackable programs, evading antivirus software, and EDR (Endpoint Detection and Response) systems.

- Supports searching for x86 / x64 programs.
- May circumvent DLLMain deadlock (as it can directly use exported functions).
- Accuracy 96%

> What may be done in the future
- [ ] Add x86/x64 version of the recognizer
 
## Uses
```shell
GoDHijack> .\GoDHijack_x86.exe
Error: missing required argument
Usage:
  GoDHijack [flags]
  GoDHijack [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  find        Automated search for vulnerable programs susceptible to hijacking.
  generate    Automatically generate hijacking templates
  help        Help about any command

Flags:
  -h, --help   help for GoDHijack

Use "GoDHijack [command] --help" for more information about a command.
```

###  Use find
![alt text](image.png)
> oks.txt
![alt text](image-1.png)

## Use generate
![alt text](image-2.png)

## Check
![alt text](image-3.png)