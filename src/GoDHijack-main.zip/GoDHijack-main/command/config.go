package command

var (
	InitPath    string
	InitOutName string
)
