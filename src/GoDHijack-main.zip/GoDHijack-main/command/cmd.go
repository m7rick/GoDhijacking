package command

import (
	"GoDLLHijack/src"
	"fmt"
	"log"
	"os"

	"github.com/spf13/cobra"
)

var (
	rootCmd = &cobra.Command{
		Use:   "GoDHijack",
		Short: "Red Team Rapid DLL Hijacking Tool",
		Long:  "Assist the Red Team in quickly identifying programs susceptible to DLL hijacking in their daily work.",
		PreRunE: func(cmd *cobra.Command, args []string) error {
			// 检查是否没有提供参数
			if len(args) == 0 {
				return fmt.Errorf("missing required argument")
			}
			return nil
		},
		Run: func(cmd *cobra.Command, args []string) {

		},
	}

	findDLL = &cobra.Command{
		Use:   "find",
		Short: "Automated search for vulnerable programs susceptible to hijacking.",
		Run: func(cmd *cobra.Command, args []string) {
			// 获取命令的参数值
			InitPath, _ = cmd.Flags().GetString("path")
			InitOutName, _ = cmd.Flags().GetString("output")
			archs, _ := cmd.Flags().GetString("arch")

			// 使用 os.Stat() 函数检查路径是否存在
			_, err := os.Stat(InitPath)
			if err == nil {
				log.Println("[+] Path :", InitPath)
				log.Println("[+] Output Name :", InitOutName)
				log.Println("[+] PE Arch Option :", archs)
				src.FindPath(InitPath, InitOutName, archs)
			} else if os.IsNotExist(err) {
				log.Println("[*] Path does not exist")
				return
			} else {
				log.Println("[*] Error:", err)
				return
			}

		},
	}

	generate = &cobra.Command{
		Use:   "generate",
		Short: "Automatically generate hijacking templates",
		Run: func(cmd *cobra.Command, args []string) {
			// 获取命令的参数值
			filepath, _ := cmd.Flags().GetString("file")
			mode, _ := cmd.Flags().GetString("mode")
			bools, _ := cmd.Flags().GetBool("msg")

			if mode != "GO" && mode != "CPP" {
				// Mode is neither "GO" nor "CPP"
				log.Println("[*] Enter the template language correctly （GO ｜ CPP）")
				return
			}

			// 使用 os.Stat() 函数检查路径是否存在
			_, err := os.Stat(filepath)
			if err == nil {
				log.Println("[+] File Path :", filepath)
				log.Println("[+] Generate Mode :", mode)
				log.Println("[+] Msg Options :", bools)
				src.DLLParse(filepath, mode, bools)

			} else if os.IsNotExist(err) {
				log.Println("[*] File Path does not exist")
				return
			} else {
				log.Println("[*] Error:", err)
				return
			}

		},
	}
)

func generateCommand() {
	generate.Flags().StringP("file", "f", "", "Specify the target file path")
	generate.Flags().StringP("mode", "m", "GO", "Generate Template Language (GO | CPP)")
	generate.Flags().BoolP("msg", "i", false, "Whether to open the infobox (false ｜ True)")
	rootCmd.AddCommand(generate)
}

func findCommand() {
	findDLL.Flags().StringP("path", "p", "", "Specify the target path")
	findDLL.Flags().StringP("output", "o", "oks.txt", "File name to save the results")
	findDLL.Flags().StringP("arch", "a", "all", "Generate Template Language (all | 32 | 64)")
	rootCmd.AddCommand(findDLL)

}
func Initcmd() {
	findCommand()
	generateCommand()
	rootCmd.Execute()

}
