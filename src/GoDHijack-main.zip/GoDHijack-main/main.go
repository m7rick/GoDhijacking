// Author: @m7rick
package main

import "GoDLLHijack/command"

func main() {

	// src.DLLParse("./MpClient.dll", "CPPM")
	// src.ParseAndPrintImports("./filetest/MpCmdRun.exe")

	// src.FindPath("./")

	command.Initcmd()

}
