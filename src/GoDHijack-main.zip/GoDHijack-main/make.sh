#/bin/bash

export CGO_ENABLED=1
export GOOS=windows

CC=x86_64-w64-mingw32-gcc GOARCH=amd64 go build -ldflags="-w -s" -trimpath -o GoDHijack_x64.exe
CC=i686-w64-mingw32-gcc GOARCH=amd64 go build -ldflags="-w -s" -trimpath -o GoDHijack_x86.exe